import React from 'react'
import style from "./navbar.module.sass"



const Navbar = () => {
  return (
    <div  className={style.navbar}>
      <div className={style.name}>
      <div>S.VELANKANNI SANTHOSH</div>
      <div className={style.degree}>BSC.Computer Science</div>
      </div>
        
        
      
    </div>
  )
}

export default Navbar
